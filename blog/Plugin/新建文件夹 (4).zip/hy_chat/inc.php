<?php !defined('HY_PATH') && exit('HY_PATH not defined.'); ?>
{"width":"500","name":"hy_chat","gn":"op","size":"500","textsize":"10000","rgb1":"#292929","rgb2":"#14171b"}