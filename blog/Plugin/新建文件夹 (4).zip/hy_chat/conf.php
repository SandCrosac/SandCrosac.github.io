<?php
return array(
    'name' => '聊天室',
    'user' => 'krabs',
    'icon' => 'comments',
    'mess' => '提供在线聊天室，在首页右下角处可以点开聊天室界面。目前仅支持PC端',
    'version' => '2.1',
);