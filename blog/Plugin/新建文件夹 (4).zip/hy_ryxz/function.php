<?php
function plugin_install(){
    return true;
}
function plugin_uninstall(){
    return true;
}
                    