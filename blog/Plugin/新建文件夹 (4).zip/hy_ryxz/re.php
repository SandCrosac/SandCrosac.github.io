<?php
return array(
	'View/tlmsu/index_index.html'=>array(
		'a1'=>'b1'
	),

);