<?php
return array(
    'name' => 'SMTP邮件发送',
    'user' => '哄着自己玩',
    'icon' => '',
    'mess' => 'SMTP邮件发送，功能简单主要解决hybbs自带邮件发送问题，支持各大邮箱平台。小提示：安装后直接配置hybbs的邮箱信息就行了。',
    'version' => '1.3',
);