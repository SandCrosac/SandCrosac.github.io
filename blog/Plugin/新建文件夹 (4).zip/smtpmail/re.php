<?php
/**
 * Created by PhpStorm.
 * User: 哄着自己玩
 * Date: 2017/12/12
 * Time: 15:03
 */
return array(
    'Action/User.php'=>array(
        //替换发送方法
        're/a_User_1.php'=>'re/a_User_2.php',
        're/a_User_a.php'=>'re/a_User_b.php',
    ),

);