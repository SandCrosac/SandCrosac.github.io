<?php !defined('HY_PATH') && exit('HY_PATH not defined.'); ?>
{"t_m_thread_index_12.hook":"10"}