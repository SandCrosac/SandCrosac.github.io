<?php
return array(
    'name' => '帖子加精',
    'user' => '飞哥',
    'icon' => '',
    'mess' => '帖子加精！论坛必备插件',
    'version' => '2.0',
);